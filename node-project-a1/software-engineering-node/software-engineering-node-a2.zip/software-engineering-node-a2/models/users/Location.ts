export default interface Location {
    latitude: number,
    longitude: number
};